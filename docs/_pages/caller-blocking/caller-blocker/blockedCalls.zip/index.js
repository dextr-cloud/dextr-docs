let AWS = require('aws-sdk');
let dynamodb = new AWS.DynamoDB.DocumentClient();

exports.handler = function(event, context, callback) {

var instancename= event.Details.Parameters.InstanceName;
var blockeddisposition= event.Details.Parameters.BlockedDisposition;
var tablename = 'dextr-' + instancename;
var phone2 = event.Details.ContactData.CustomerEndpoint.Address;

var params = {
  ExpressionAttributeValues: {
    ":v1": blockeddisposition,
    ":v2":  phone2,

  }, 
  ExpressionAttributeNames: {
    "#x": "Disposition",
    "#y": "CustomerEndpoint"
  }, 
  KeyConditionExpression: "#x = :v1 AND #y = :v2", 
  TableName: tablename,
  IndexName: 'Disposition-CustomerEndpoint-index'
};

dynamodb.query(params, function(err, data){
  if(err){
    callback(err, null);
  }
  else{
    if (data.Items[0] === undefined){
      let resultMap = {
        response : 'nomatch'
        }
      callback(null, resultMap);
      //console.log(resultMap);
    }
    else{
      let resultMap = {
        response : 'match'
        }
      callback(null, resultMap);
      //console.log(resultMap);
    }
   
  }
});
};